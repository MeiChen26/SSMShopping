create definer = root@localhost trigger tri_insertColor
  after INSERT
  on r_goodscolor
  for each row
begin
 declare gid int;
 declare cid int;
 declare sid int; 
 declare sname varchar(50);
 declare cname varchar(50);
 DECLARE done INT DEFAULT false;
 DECLARE cur1 CURSOR FOR (SELECT size_id FROM r_goodssize WHERE goods_id=new.goods_id);
 DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
  
  OPEN cur1; 
  read_loop:LOOP
  FETCH cur1 INTO sid;
  IF done 
   THEN LEAVE read_loop;
  END IF;
   set sname=(select size_name from t_size where size_id=sid);
   set cname=(select color_name from t_color where color_id=new.color_id);
   insert into t_stock values(null,new.goods_id,sid,sname,new.color_id,cname,0,0);  
  END LOOP; 
  CLOSE cur1;  
 end;

