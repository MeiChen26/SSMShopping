create definer = root@localhost trigger tri_insertSize
  after INSERT
  on r_goodssize
  for each row
begin
 declare gid int;
 declare cid int;
 declare sid int; 
 declare sname varchar(50);
 declare cname varchar(50);
 DECLARE done INT DEFAULT false;
 DECLARE cur1 CURSOR FOR (SELECT color_id FROM r_goodscolor WHERE goods_id=new.goods_id);
 DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
  
  OPEN cur1; 
  read_loop:LOOP
  FETCH cur1 INTO cid;
  IF done 
   THEN LEAVE read_loop;
  END IF;
   set sname=(select size_name from t_size where size_id=new.size_id);
   set cname=(select color_name from t_color where color_id=cid);
   insert into t_stock values(null,new.goods_id,new.size_id,sname,cid,cname,0,0);  
  END LOOP; 
  CLOSE cur1;  
 end;

