create definer = root@localhost trigger tri_deleteColor
  after DELETE
  on r_goodscolor
  for each row
begin
 declare gid int;
 declare cid int;
 declare sid int; 
 DECLARE done INT DEFAULT false;
 DECLARE cur1 CURSOR FOR (SELECT size_id FROM r_goodssize WHERE goods_id=old.goods_id);
 DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
  
  OPEN cur1; 
  read_loop:LOOP
  FETCH cur1 INTO sid;
  IF done 
   THEN LEAVE read_loop;
  END IF;
   delete from t_stock where goods_id=old.goods_id and size_id=sid and color_id=old.color_id;  
  END LOOP; 
  CLOSE cur1;  
 end;

