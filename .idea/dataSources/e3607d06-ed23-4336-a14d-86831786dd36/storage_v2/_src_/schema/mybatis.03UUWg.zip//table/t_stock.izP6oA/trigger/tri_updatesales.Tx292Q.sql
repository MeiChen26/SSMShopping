create definer = root@localhost trigger tri_updateSales
  after UPDATE
  on t_stock
  for each row
begin
 declare salesNum int;
 declare stockNum int;
 set salesNum=(select sum(sales_num) from t_stock where goods_id=new.goods_id);
 set stockNum=(select sum(stock_num) from t_stock where goods_id=new.goods_id);
 update t_goods set goods_sales=salesNum,goods_stock=stockNum where goods_id=new.goods_id;
 end;

