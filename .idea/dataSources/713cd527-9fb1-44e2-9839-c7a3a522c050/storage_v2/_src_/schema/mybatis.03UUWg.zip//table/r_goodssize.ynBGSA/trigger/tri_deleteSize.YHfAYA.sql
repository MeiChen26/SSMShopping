create definer = root@localhost trigger tri_deleteSize
  after DELETE
  on r_goodssize
  for each row
begin
 declare gid int;
 declare cid int;
 declare sid int; 
 DECLARE done INT DEFAULT false;
 DECLARE cur1 CURSOR FOR (SELECT color_id FROM r_goodscolor WHERE goods_id=old.goods_id);
 DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
  
  OPEN cur1; 
  read_loop:LOOP
  FETCH cur1 INTO cid;
  IF done 
   THEN LEAVE read_loop;
  END IF;
   delete from t_stock where goods_id=old.goods_id and size_id=old.size_id and color_id=cid;  
  END LOOP; 
  CLOSE cur1;  
 end;

