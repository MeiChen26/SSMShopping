create definer = root@localhost trigger tri_updateStockAndSales
  after UPDATE
  on t_order
  for each row
begin
 declare sname varchar(50);
 declare cname varchar(50);
 declare odid int; 
 declare gid int;
 declare n int;
 declare s int;
 DECLARE done INT DEFAULT false;
 DECLARE cur1 CURSOR FOR (SELECT odetail_id FROM t_orderdetail WHERE order_id=new.order_id);
 DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
  set s = (select order_status from t_order where order_id=new.order_id);
  OPEN cur1; 
  read_loop:LOOP
  FETCH cur1 INTO odid;
  IF done 
   THEN LEAVE read_loop;
  END IF;
    set sname = (select odetail_size from t_orderdetail where odetail_id=odid); 
    set cname = (select odetail_color from t_orderdetail where odetail_id=odid); 
    set n = (select odetail_num from t_orderdetail where odetail_id=odid);
    set gid = (select goods_id from t_orderdetail where odetail_id=odid);
  if s=5 then
   update t_stock set sales_num = sales_num + n where goods_id = gid and size_name=sname and color_name=cname;
  elseif s=4 then
   update t_stock set stock_num = stock_num - n where goods_id = gid and size_name=sname and color_name=cname;
  elseif s=8 then
   update t_stock set stock_num = stock_num + n where goods_id = gid and size_name=sname and color_name=cname;
  end if;
  
  END LOOP; 
  CLOSE cur1;  
 end;

